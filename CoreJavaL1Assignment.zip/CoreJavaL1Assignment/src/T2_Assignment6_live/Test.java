/*Assignment 6:
Write an interface called Playable, with a method
void play();
Let this interface be placed in a package called music.
Write a class called Veena which implements Playable interface. Let this class be placed in a
package music.string
Write a class called Saxophone which implements Playable interface. Let this class be placed in
a package music.wind
Sensitivity: Internal & Restricted
Write another class Test in a package called live. Then,
a. Create an instance of Veena and call play() method
b. Create an instance of Saxophone and call play() method
c. Place the above instances in a variable of type Playable and then call play()*/
package T2_Assignment6_live;

import T2_Assignment6_music.playable;
import T2_Assignment6_music.string.veena;
import T2_Assignment6_music.wind.saxophone;

public class Test {

	public static void main(String[] args) {
		veena v=new veena();
		v.play();
		saxophone s = new saxophone();
		s.play();
		playable p;
		p=new veena();
		p.play();
		p=new saxophone();
		p.play();

	}

}
