package T2_Assignment6_music;

public interface playable {
	
	public void play();

}
