package T2_Assignment6_music.string;

import T2_Assignment6_music.playable;

public class veena implements playable {

	public void play() {
		System.out.println("Veena is playing");
	}
	
}
