package T2_Assignment6_music.wind;

import T2_Assignment6_music.playable;

public class saxophone implements playable {

	public void play() {
	
		System.out.println("Saxophone is playing");
	}

}
