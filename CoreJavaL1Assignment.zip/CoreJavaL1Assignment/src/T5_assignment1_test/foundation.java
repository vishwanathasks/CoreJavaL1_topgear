package T5_assignment1_test;

public class foundation {
	
	private int Var1=10;
	int Var2=20;
	protected int Var3=30;
	public int Var4=40; 

}
