/*Assignment 2:
Write a Java program to print the result of the following operations. Declare variables and
initialize them with given values
a. -5 + 8 * 6
b. (55+9) % 9
c. 20 + -3*5 / 8
d. 5 + 15 / 3 * 2 - 8 % 3*/

package Topic1_JVMConcepts_LanguageBasics;
public class Assignment2 {
	public static void main(String[] args) {
		
		int result1= -5+8*6;
		int result2= (55+9)%9;
		double result3= 20+ (float)(-3*5)/8;
		double result4= 5+15/3*2-8%3;
		
		System.out.println("Result 1 is: "+ result1);
		System.out.println("Result 2 is: "+ result2);
		System.out.println("Result 3 is: "+ result3);
		System.out.println("Result 4 is: "+ result4);
	}
}
