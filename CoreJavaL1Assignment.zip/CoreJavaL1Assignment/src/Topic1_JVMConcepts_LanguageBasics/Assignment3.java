//Assignment 3: Write a Java program to convert minutes into a number of years and days.
package Topic1_JVMConcepts_LanguageBasics;

import java.util.Scanner;

public class Assignment3 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter minutes to convert: ");
		int minutes,minutes1;
		minutes=minutes1=in.nextInt();
		int years=0;
		int days=0;
		if(minutes<0)
			System.out.println("minutes must be greater than 0");
		else {
			while(minutes> 1440) {
				days=minutes/1440;
				if(days>=365) {
					years=days/365;
					days=days%365;
				}
				minutes=minutes%1440;
			}
			System.out.println("After conversion "+ minutes1+" minutes is equals to "+ years+" Year/s, "+days+" Day/s and "+minutes+" minute/s.");
		}
		in.close();
	}

}
