//Assignment 7: Write a Java program to calculate the factorial of a number without using any loop.
package Topic1_JVMConcepts_LanguageBasics;
import java.util.Scanner;
public class Assignment7 {

	public static void main(String[] args) {

		Scanner in =new Scanner(System.in);
		System.out.println("Enter number to find the factorial: ");
		int m= in.nextInt();
		if(m<0)
			System.out.println("Number should be greater than or equal to zero");
		else {
			int fact=fact(m);
			System.out.println("The factorial of number "+m+" is "+fact);
		}
		in.close();
	}
	public static int fact(int n)
	{
		if(n==0)
			return 1;
		else
			return (n*fact(n-1));
	}

}
