/*Assignment 1:
Write a program to create a class Book with the following
- attributes: -isbn, title, author, price
 - methods :
 i. Initialize the data members through parameterized constructor
 ii. displaydeta ils() to display the details of the book
 iii. discountedprice() : pass the discount percent, calculate the discount on price and find
the amount to be paid after discount
 - task :
 Create an object book, initialize the book and display the details along with the discounted
price*/

package Topic2_object_Oriented_Concepts;

public class Assignment1 {

	public static void main(String[] args) {
		
		Assignment1_Book b1=new Assignment1_Book(1000, "The Great History","D J Arjun", 525 );
		Assignment1_Book b2= new Assignment1_Book(1225, "The half girlfriend","Chetan B", 600.25);
		Assignment1_Book b3= new Assignment1_Book(8225,"Karmoda","Kuvempu", 1200);
		
		b1.ils();
		b1.discountedprice(5);
		
		b2.ils();
		b2.discountedprice(7.5);
		
		b3.ils();
		b3.discountedprice(10);

	}

}
