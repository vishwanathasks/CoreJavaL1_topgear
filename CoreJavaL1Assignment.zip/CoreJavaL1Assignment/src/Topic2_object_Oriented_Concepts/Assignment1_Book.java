package Topic2_object_Oriented_Concepts;

public class Assignment1_Book {
	
	int isbn;
	String title;
	String author;
	double price;

	public Assignment1_Book(int isbn, String title, String author, double price) {
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		this.price = price;
	}
	
	public void ils() {
		
		System.out.println("------------------------------------------");
		System.out.println("Name of the book: "+ title);
		System.out.println("isbn: "+ (int)isbn);
		System.out.println("Author of the book: "+ author);
		System.out.println("Price: "+ String.format("%.2f",price)+" Rs");
		System.out.println("");
	}
	
	public void discountedprice(double discount) {
		double disA= (price/100)*discount;
		double disP= price-disA;
		System.out.println("Original price: "+String.format("%.2f",price)+" Rs");
		System.out.println("Discount amount is: "+ String.format("%.2f",disA)+" Rs");
		System.out.println("Amount to be paid: "+ String.format("%.2f",disP)+" Rs");
		System.out.println("------------------------------------------");
	}

}
