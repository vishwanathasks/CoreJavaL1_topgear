/*Assignment 3:
Write a program to create a class Book with the following data members: isbn, title and price.
Inherit the class Book to two derived classes : Magazine and Novel with the following data
members:
Magazine: type
Novel : author
Populate the details using constructors.
Create a magazine and Novel and display the details.
*/
package Topic2_object_Oriented_Concepts;

public class Assignment3 {

	public static void main(String[] args) {
		
		Assignment3_Magazine m1=new Assignment3_Magazine(8800,"Bangalore times", 25, "Weekly edition");
		Assignment3_Magazine m2= new Assignment3_Magazine(1111,"Karmaveera", 40, "Monthly edition");
		Assignment3_Novel n1= new Assignment3_Novel(12510, "Nenapu", 125.50, "KP");
		Assignment3_Novel n2= new Assignment3_Novel(12511, "Adventure in Amazon", 1250.75, "James Peter");
		
		n1.display();
		m1.display();
		n2.display();
		m2.display();

	}

}
