package Topic2_object_Oriented_Concepts;

public class Assignment3_Book {
	int isbn;
	String title;
	double price;
	public Assignment3_Book(int isbn, String title, double price) {
		this.isbn = isbn;
		this.title = title;
		this.price = price;
	}
	
public void display() {
		
		System.out.println("------------------------------------------");
		System.out.println("Name : "+ title);
		System.out.println("isbn: "+ (int)isbn);
		System.out.println("Price: "+ String.format("%.2f",price)+" Rs");
	}
	
}
