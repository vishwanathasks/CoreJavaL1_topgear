package Topic2_object_Oriented_Concepts;

public class Assignment3_Magazine extends Assignment3_Book{
	String type;
	public Assignment3_Magazine(int isbn, String title, double price, String type) {
		super(isbn, title, price);
		this.type=type;
	}
	
	public void display() {
		super.display();
		System.out.println("Type of Magazine is: "+ type);
	}

}
