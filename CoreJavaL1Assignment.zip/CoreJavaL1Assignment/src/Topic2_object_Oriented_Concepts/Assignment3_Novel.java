package Topic2_object_Oriented_Concepts;

public class Assignment3_Novel extends Assignment3_Book {

	String author;
	public Assignment3_Novel(int isbn, String title, double price, String author) {
		super(isbn, title, price);
		this.author=author;
	}
	
	public void display() {
		super.display();
		System.out.println("Name of Author: "+author);
	}

}
