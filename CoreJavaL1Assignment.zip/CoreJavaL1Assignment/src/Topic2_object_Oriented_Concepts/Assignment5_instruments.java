/*Assignment 5:
Create an abstract class Instrument which is having the abstract function play.
Create three more sub classes from Instrument which is Piano, Flute, Guitar.
Override the play method inside all three classes printing a message
�Piano is playing tan tan tan tan � for Piano class
�Flute is playing toot toot toot toot� for Flute class
�Guitar is playing tin tin tin � for Guitar class
You must not allow the user to declare an object of Instrument class.
Create an array of 10 Instruments.
Assign different type of instrument to Instrument reference.
Check for the polymorphic behavior of play method.
Use the instanceof operator to print that which object stored at which index of instrument array.*/

package Topic2_object_Oriented_Concepts;

abstract class instruments
{
	abstract void play();
}

class piano extends instruments
{
	void play()
	{
	    System.out.println("piano is palying tan tan tan tan");
	}
}

class flute extends instruments
{
	void play()
	{
	    System.out.println("flute is palying toot toot toot toot");
	}
}

class guitar extends instruments
{
	void play()
	{
	    System.out.println("guitar is palying tin tin tin tin");
	}
}

public class Assignment5_instruments
{
    public static void main(String args[])
    {
       instruments[] instrument=new instruments[10];
        instrument[0]=new piano();
        instrument[1]=new guitar();
        instrument[2]=new flute();
        instrument[3]=new guitar();
        instrument[4]=new flute();
        instrument[5]=new piano();
        instrument[6]=new flute();
        instrument[7]=new guitar();
        instrument[8]=new piano();
        instrument[9]=new flute();
        
        for(int i=0;i<10;i++)
            instrument[i].play();
        
    }
}
