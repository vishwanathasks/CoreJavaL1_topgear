/*Assignment 1:
Write a program to accept name and age of a person from the command prompt(passed as
arguments when you execute the class) and ensure that the age entered is >=18 and < 60. Display
proper error messages. The program must exit gracefully after displaying the error message in
case the arguments passed are not proper. (Hint : Create a user defined exception class for
handling errors.)*/
package Topic3_Exceptions_String_Concepts;

import java.util.Scanner;

public class Assignment1_age {

	static int f=0;

	public static void main(String[] args) {
		
		Scanner in=new Scanner(System.in);
		System.out.println("Enter your name and age: ");
		@SuppressWarnings("unused")
		String name=in.next();
		int age= in.nextInt();
		in.close();
		try
		{
			if(age <18|| age >60)
				throw new myException();
		}
		catch(myException e)
		{
			f=1;
			System.out.println("Exception:" +e);
		}
		if(f==0)
			System.out.println("Your details accepted");
		
	}
}

class myException extends Exception
{
	private static final long serialVersionUID = 1L;
	public myException()
	{
		System.out.println("My exception is thrown");
	}
	public String toString()
	{
		return "My exception Object: Age cannot be < 18 and cannot be >60";
	}
}


