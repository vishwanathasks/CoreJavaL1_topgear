/*Assignment 2:
Write a Program to take care of Number Format Exception if user enters values other that integer
for calculating average marks of 2 students. The name of the students and marks in 3 subjects are
passed as arguments while executing the program.*/
package Topic3_Exceptions_String_Concepts;

import java.util.Scanner;

public class Assignment2 {

	public static void main(String[] args) throws NumberFormatException{
		Scanner in = new Scanner(System.in);
		
		String[] name = new String[2];
		for (int j = 0; j < 2; j++) {
			int sum = 0;
			double average = 0;
			int[] sub = new int[3];
			System.out.println("Enter name of the Student: ");
			name[j] = in.nextLine();
			System.out.println("Enter three subject marks: ");
			for (int i = 0; i <3; i++) {
				try {
					if (in.hasNextInt())
						sub[i] = in.nextInt();
					else
						throw new NumberFormatException();

				} catch (ArithmeticException e) {
					System.out.println(e.getMessage());
				}

				sum = sum + sub[i];
			}
			in.nextLine();
			average = sum / 3;
			System.out.println("Name of student: " + name[j] + " and Average marks is: " + average);

		}
		in.close();

	}

}
