/*Assignment 4:
Write a program to check whether the given string is a palindrome or not.
[Hint :You have to extract each character from the beginning and end of the String and compare
it with each other. String x=�Malayalam�; char c= x.charAt(i) where i is the index]*/

package Topic3_Exceptions_String_Concepts;

import java.util.Scanner;

public class Assignment4 {

	public static void main(String[] args) {
		Scanner in =new Scanner(System.in);
		System.out.println("Enter a string: ");
		String s=in.nextLine();
		s=s.toLowerCase();
		boolean b=true;
		int len=s.length();
		for(int i=0;i<len;i++) {
			if(s.charAt(i)!=(s.charAt(len-1-i)))
				b=false;		
		}
		if(b)
			System.out.println("Given string is palindrome");
		else
			System.out.println("Given string is not palindrome");
		in.close();
	}

}
