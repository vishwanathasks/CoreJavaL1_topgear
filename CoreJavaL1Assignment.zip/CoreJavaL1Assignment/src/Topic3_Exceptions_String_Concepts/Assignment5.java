/*Assignment 5:
Write a program to check the no.of occurrences of a given character within the given string
without using any loop. [Hint: String str=�How was your day today�; char c=�a�; no.of
occurrences of a is=3]*/

package Topic3_Exceptions_String_Concepts;

import java.util.Scanner;

public class Assignment5 {

	public static void main(String[] args) {
		Scanner in =new Scanner(System.in);
		System.out.println("Enter a string: ");
		String s=in.nextLine();
		System.out.println("Enter a character to check the occurance");
		char t=in.next().charAt(0);
		//int count= count(s,t,0);
		
		System.out.println("Number of occurance of character "+t+" is "+count(s,t,0));
		
		in.close();
	}
	
	public static int count(String myString, char searchChar, int index) {
	    if (index >= myString.length()) {
	        return 0;
	    }
	    if(myString.charAt(index) == searchChar)
	    	return 1+ count(myString, searchChar, index + 1);
	    return 0+ count(myString, searchChar, index + 1);
	    	
	}

}
