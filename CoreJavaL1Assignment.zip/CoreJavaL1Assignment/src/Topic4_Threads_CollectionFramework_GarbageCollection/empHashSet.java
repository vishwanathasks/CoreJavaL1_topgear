/*Assignment 5:
Write a program to store a group of employee names into a HashSet, retrieve the elements one by
one using an Iterator.*/
package Topic4_Threads_CollectionFramework_GarbageCollection;

import java.util.HashSet;
import java.util.Iterator;

public class empHashSet {

	public static void main(String[] args) {
		
		HashSet<String> empSet=new HashSet<>();
		empSet.add("Kamala");
		empSet.add("Anusha");
		empSet.add("Kumar");
		empSet.add("Sunil");
		empSet.add("Suresh");
		empSet.add("Vishwanath");
		empSet.add("Navya");
		
		Iterator<String> itr= empSet.iterator();
		
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}
