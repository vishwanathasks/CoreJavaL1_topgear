/*Assignment 6:
Develop a java class that has finalize method which displays �Finalize method called�. Create
another class which creates objects of the previous class and it uses the same object reference for
creating these objects. For example, if A1 is the class name, then the objects are created as 
Sensitivity: Internal & Restricted
below :
A1 a = new A1();
a = new A1();
a = new A1();
When the statement Runtime.getRuntime().gc() is invoked, how many times the finalize method
is called*/
package Topic4_Threads_CollectionFramework_GarbageCollection;

public class gcCalling {

	public static void main(String[] args) {
		gcCalling gc=new gcCalling();
		gc=new gcCalling();
		gc= new gcCalling();
		
		Runtime.getRuntime().gc();
		
		System.out.println("Garbage collection Ended");

	}
	
    protected void finalize()   
    {   
        System.out.println("finalize method called");   
    }   

}
