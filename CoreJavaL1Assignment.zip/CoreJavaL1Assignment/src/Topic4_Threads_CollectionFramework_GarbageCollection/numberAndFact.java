/*Assignment 1:
Write a Java Program, where one thread prints a number ( Generate a random number
using Math.random) and another thread prints the factorial of that given number. Both
the outputs should alternate each other.
Eg: Number : 2
 Factorial of 2 : 2
 Number : 5
 Factorial of 5 : 120
The program can quit after executing 5 times.*/

package Topic4_Threads_CollectionFramework_GarbageCollection;

class myClass1 implements Runnable {
	int number;
	public myClass1(int n) {
		this.number=n;
	}
	public void run() {
		System.out.println("Number is : " + number);
	}
}

class myClass2 implements Runnable {
	int number;
	public myClass2(int n) {
		this.number=n;
	}
	public void run() {
		int fact = 1;
		if (number == 0) {
			System.out.println("facttorial  of number " + number + " is: 1");
		} else {
			for (int i = 1; i <= number; i++) {
				fact = fact * i;
			}
			System.out.println("facttorial  of " + number + " is: " + fact);
		}
	}
}

public class numberAndFact {

	public static void main(String[] args) throws InterruptedException {

		for(int i=0;i<5;i++) {
			int rd=(int) (Math.random()*10);
			Runnable r1 = new myClass1(rd);
			Runnable r2 = new myClass2(rd);
			Thread t1 = new Thread(r1);
			Thread t2 = new Thread(r2);
			Thread.sleep(500);
			t1.start();
			t2.start();
			
		}
		
	}
}
