/*Assignment 2:
Write a Java Program which will print the current time on the console every 2 seconds.
After doing this activity for 20 seconds the program quits.*/
package Topic4_Threads_CollectionFramework_GarbageCollection;
import java.util.Date;
public class printTime2seconds {

	public static void main(String[] args) throws InterruptedException {
		long start = System.currentTimeMillis();
		while (true) {
			Thread.sleep(2000);
			System.out.println(new java.sql.Time(new Date().getTime()));
			long finish = System.currentTimeMillis();
			if (finish - start >= 22000) {
				break;
			}
		}
	}
}
