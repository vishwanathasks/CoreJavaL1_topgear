/*Assignment 4:
Write a program creates a HashMap to store name and phone number (Telephone book). When
name is give, we can get back the corresponding phone number.*/

package Topic4_Threads_CollectionFramework_GarbageCollection;

import java.util.HashMap;
import java.util.Scanner;

public class telephoneBook {

	public static void main(String[] args) {
		HashMap<String, String> TelephoneBook= new HashMap<String, String>();
		TelephoneBook.put("VISHWA","9448123");
		TelephoneBook.put("SANA","2767276");
		TelephoneBook.put("ANI","9646467");
		TelephoneBook.put("KAVYA","8363838");
		TelephoneBook.put("TANU","8929962");
		TelephoneBook.put("SHASHI","6383992");
		
		Scanner in= new Scanner(System.in);
		System.out.println("Enter a name: ");
		String name=in.next().toUpperCase();
		
		if(TelephoneBook.containsKey(name))
			System.out.println("Number is: "+TelephoneBook.get(name));
		else
			System.out.println("Not found");
		
		in.close();
		
	}

}
