package Topic5_CommandLineArgs_SystemProperties_Packaging;
import T5_assignment1_test.*;
public class Assignment1 {

	public static void main(String[] args) {
		
		foundation f=new foundation();
//		System.out.println(f.Var1);
//		System.out.println(f.Var2);
//		System.out.println(f.Var3);
		System.out.println(f.Var4);
		
	}

}
