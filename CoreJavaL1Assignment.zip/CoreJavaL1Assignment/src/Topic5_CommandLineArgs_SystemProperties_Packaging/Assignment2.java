/*Assgnment 2:
Write a Program to accept two Strings Wipro Bangalore as command line arguments and print
the output �Wipro Technologies Bangalore� If the command line is �ABC Mumbai�, then it
should print �ABC Technologies Mumbai� .*/

package Topic5_CommandLineArgs_SystemProperties_Packaging;

import java.util.Scanner;

public class Assignment2 {

	public static void main(String[] args) {
		
		Scanner in= new Scanner(System.in);
		System.out.println("Enter two word string:");
		String s=in.nextLine();
		String s1="";
		String s2="";
		int n=s.split(" ").length;
		if(n!=2)
			System.out.println("Invalid string!! Enter a two word string");
		else {
			s1=s.split(" ")[0];
			s2=s.split(" ")[1];
			System.out.println(s1+" Technologies "+s2);
		}
	}
}
